OFF THE CLOCK personal website

Open off-the-clock-personal-website.html in a browser to preview it.
To personalize:
1. Replace OFF THE CLOCK with your preferred site/brand name if desired.
2. Search the HTML for YOUR_EMAIL_HERE and replace it with your email address to activate the email form.
3. Replace the sample social links and sample journal cards with your real profiles and posts.
4. To put it online, upload the HTML to a web host or website builder that supports custom HTML.

The site is a responsive, single-file starter website. The contact form opens the visitor's email app after you add your address; it does not store submissions.
